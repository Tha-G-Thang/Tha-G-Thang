import sys
import xbmc
from default import (
    PlaylistService,
    log,
    check_scheduled_updates,
    load_json,
    background_scan,
    record_update_time,
    CONFIG_FILE
)

class EnhancedPlaylistService(PlaylistService):
    def __init__(self):
        super().__init__()
        self.scan_interval = 300  # 5 minutes in seconds

    def run(self):
        """Enhanced service loop with better logging"""
        log("Service started", xbmc.LOGINFO)
        
        while not self.monitor.abortRequested():
            try:
                if check_scheduled_updates():
                    self._run_scheduled_update()
                
                if self.monitor.waitForAbort(self.scan_interval):
                    break
                    
            except Exception as e:
                log(f"Service error: {str(e)}", xbmc.LOGERROR)
                xbmc.sleep(5000)  # Prevent tight error loops

        log("Service stopped", xbmc.LOGINFO)

    def _run_scheduled_update(self):
        """Handle scheduled updates with progress tracking"""
        log("Starting scheduled update", xbmc.LOGINFO)
        sets = load_json(CONFIG_FILE) or {}
        
        if not sets:
            log("No sets configured for update", xbmc.LOGWARNING)
            return
            
        total_files = 0
        for set_name, set_data in sets.items():
            file_count = background_scan(set_data.get('folders', []))
            total_files += file_count
            log(f"Scanned {file_count} files for {set_name}", xbmc.LOGDEBUG)
        
        record_update_time()
        log(f"Update completed. Total files scanned: {total_files}", xbmc.LOGINFO)

if __name__ == '__main__':
    try:
        log("Playlist Generator Service starting", xbmc.LOGINFO)
        service = EnhancedPlaylistService()
        service.run()
    except Exception as e:
        log(f"Service failed to start: {str(e)}", xbmc.LOGERROR)
        raise