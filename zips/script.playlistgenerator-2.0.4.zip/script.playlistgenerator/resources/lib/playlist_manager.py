import os
import re
import random
import xbmcvfs
import urllib.parse # Import for unquoting
from datetime import datetime
from functools import cmp_to_key
from typing import Dict, List, Any, Optional

import xbmc
import xbmcgui
import xbmcaddon

import resources.lib.utils as utils
import resources.lib.downloader as downloader

class PlaylistManager:
    def __init__(self) -> None:
        self.sets: Dict[str, Any] = utils.load_json(utils.CONFIG_FILE)
        self.playlists_generated = 0
        self.files_processed_count = 0
        self.folders_processed_count = 0

    def _get_setting(self, setting_id: str) -> str:
        return utils.get_setting(setting_id)

    def _get_setting_bool(self, setting_id: str) -> bool:
        return self._get_setting(setting_id) == 'true'

    def _get_setting_int(self, setting_id: str) -> int:
        try:
            return int(self._get_setting(setting_id))
        except ValueError:
            return 0

    def _get_setting_float(self, setting_id: str) -> float:
        try:
            return float(self._get_setting(setting_id))
        except ValueError:
            return 0.0

    def _get_current_addon_settings(self) -> Dict[str, str]:
        return utils.get_all_addon_settings()

    def _apply_set_settings_to_addon(self, settings: Dict[str, str]) -> None:
        utils.set_all_addon_settings(settings)

    def _load_set_settings(self, set_name: str) -> None:
        if set_name in self.sets and 'settings' in self.sets[set_name]:
            self._apply_set_settings_to_addon(self.sets[set_name]['settings'])
        else:
            utils.log(f"No settings found for set: {set_name}, loading default addon settings.", xbmc.LOGWARNING)
            self._apply_set_settings_to_addon(utils.get_all_addon_settings())

    def _save_set_settings(self, set_name: str, settings: Dict[str, str]) -> None:
        if set_name in self.sets:
            self.sets[set_name]['settings'] = settings
            utils.save_json(self.sets, utils.CONFIG_FILE)

    def _collect_files_for_playlist(self, folder_path: str) -> List[Dict[str, Any]]:
        """Collects files from a given folder (and its subfolders if recursive scan is enabled)
           and applies filtering, but does not generate the playlist itself.
        """
        utils.log(f"Collecting files from: {folder_path}", xbmc.LOGINFO)
        collected_files: List[Dict[str, Any]] = []
        exclude_pattern = self._get_setting('exclude_pattern').lower().split(',')
        exclude_folders = [f.lower() for f in self._get_setting('exclude_folders').lower().split(',')]
        min_file_size = self._get_setting_int('min_file_size') * 1024 * 1024
        enable_max_size = self._get_setting_bool('enable_max_size')
        max_file_size = self._get_setting_int('max_file_size') * 1024 * 1024 if enable_max_size else 0
        recursive_scan = self._get_setting_bool('recursive_scan')
        enable_date_filter = self._get_setting_bool('enable_date_filter')
        min_file_date_str = self._get_setting('min_file_date')

        min_file_date = None
        if enable_date_filter and min_file_date_str:
            try:
                min_file_date = datetime.strptime(min_file_date_str, '%Y-%m-%d')
            except ValueError:
                utils.log(f"Invalid date format for min_file_date: {min_file_date_str}", xbmc.LOGERROR)

        folders_to_scan = [folder_path] if not recursive_scan else self._get_all_subfolders(folder_path, exclude_folders)
        utils.log(f"Folders to scan ({'recursive' if recursive_scan else 'single'}): {folders_to_scan}", xbmc.LOGINFO)

        for current_folder in folders_to_scan:
            self.folders_processed_count += 1 # This count is for the entire operation
            files_in_folder: List[Dict[str, Any]] = []
            try:
                utils.log(f"Listing contents of folder: {current_folder}", xbmc.LOGINFO)
                dirs, files = xbmcvfs.listdir(current_folder)
                utils.log(f"Found {len(dirs)} directories and {len(files)} files in {current_folder}", xbmc.LOGINFO)

                for file_name in files:
                    full_path = os.path.join(current_folder, file_name)
                    is_video = self._is_video_file(file_name)
                    is_excluded = self._is_excluded(file_name, exclude_pattern)
                    
                    utils.log(f"Processing file: {file_name} (is_video: {is_video}, is_excluded: {is_excluded})", xbmc.LOGDEBUG)

                    if is_video and not is_excluded:
                        try:
                            stat = xbmcvfs.Stat(full_path)
                            file_size = stat.st_size()
                            file_mtime = datetime.fromtimestamp(stat.st_mtime())

                            size_ok = file_size >= min_file_size and (not enable_max_size or file_size <= max_file_size)
                            date_ok = (not enable_date_filter or (min_file_date and file_mtime >= min_file_date))
                            
                            utils.log(f"File {file_name} - Size: {file_size} (min_ok: {file_size >= min_file_size}, max_ok: {not enable_max_size or file_size <= max_file_size}), Date: {file_mtime} (date_ok: {date_ok})", xbmc.LOGDEBUG)

                            if size_ok and date_ok:
                                files_in_folder.append({
                                    'path': full_path,
                                    'name': file_name,
                                    'size': file_size,
                                    'mtime': file_mtime
                                })
                                self.files_processed_count += 1 # This count is for the entire operation
                                utils.log(f"Added file to list: {file_name}", xbmc.LOGDEBUG)
                            else:
                                utils.log(f"File {file_name} excluded by size/date filter.", xbmc.LOGDEBUG)
                        except Exception as stat_e:
                            utils.log(f"Error getting stat for file {full_path}: {str(stat_e)}", xbmc.LOGERROR)
                    else:
                        utils.log(f"File {file_name} excluded by type or exclude pattern.", xbmc.LOGDEBUG)
            except Exception as e:
                utils.log(f"Error listing files in {current_folder}: {str(e)}", xbmc.LOGERROR)

            utils.log(f"Found {len(files_in_folder)} valid files in {current_folder} before sorting/limiting per folder.", xbmc.LOGINFO)
            self._sort_files(files_in_folder)
            
            files_per_folder_limit = self._get_setting_int('file_count') # This is the "files per folder" setting
            if files_per_folder_limit > 0 and len(files_in_folder) > files_per_folder_limit:
                files_in_folder = files_in_folder[:files_per_folder_limit]
                utils.log(f"Limited to {len(files_in_folder)} files per folder.", xbmc.LOGINFO)

            collected_files.extend(files_in_folder)
        
        utils.log(f"Total files collected from {folder_path} (and subfolders) before final global limits/rotation: {len(collected_files)}", xbmc.LOGINFO)
        return collected_files

    def _create_playlist_from_folder(self, folder_path: str, playlist_name: str) -> None:
        """This function is now a wrapper that calls _collect_files_for_playlist
           and then _generate_m3u_playlist. It is used by single-set generation or quick_scan.
           The main `create_playlist` function handles multiple folder selection.
        """
        all_files = self._collect_files_for_playlist(folder_path)

        # Apply global limits and rotation AFTER all files from a single folder's recursive scan are collected.
        total_file_limit_enabled = self._get_setting('limit_mode') == '1'
        total_file_count_limit = self._get_setting_int('total_file_count')

        utils.log(f"Total files collected from {folder_path} before overall limit: {len(all_files)}", xbmc.LOGINFO)
        if total_file_limit_enabled:
            if total_file_count_limit > 0 and len(all_files) > total_file_count_limit:
                all_files = all_files[:total_file_count_limit]
                utils.log(f"Limited to {len(all_files)} total files.", xbmc.LOGINFO)

        enable_rotation = self._get_setting_bool('enable_rotation')
        if enable_rotation:
            offset = self._get_setting_int('rotation_offset')
            if offset > 0 and len(all_files) > 0:
                offset %= len(all_files)
                all_files = all_files[offset:] + all_files[:offset]
                utils.log(f"Applied rotation with offset {offset}.", xbmc.LOGINFO)

        utils.log(f"Final number of files for playlist '{playlist_name}': {len(all_files)}", xbmc.LOGINFO)
        self._generate_m3u_playlist(playlist_name, all_files)

    def _get_all_subfolders(self, root_folder: str, exclude_folders: List[str]) -> List[str]:
        utils.log(f"Starting recursive scan from: {root_folder}", xbmc.LOGINFO)
        folders_to_scan = [root_folder]
        queue = [root_folder]
        while queue:
            current_dir = queue.pop(0)
            try:
                utils.log(f"Listing subdirectories of {current_dir} for recursion.", xbmc.LOGDEBUG)
                dirs, _ = xbmcvfs.listdir(current_dir)
                for d in dirs:
                    full_path = os.path.join(current_dir, d)
                    folder_name = d.lower()
                    if full_path.endswith(os.sep):
                        full_path = full_path[:-len(os.sep)]
                    
                    # Relying on xbmcvfs.listdir to correctly identify directories in 'dirs' list
                    if folder_name not in exclude_folders:
                        folders_to_scan.append(full_path)
                        queue.append(full_path)
                        utils.log(f"Added subfolder for scan: {full_path}", xbmc.LOGDEBUG)
                    else:
                        utils.log(f"Excluded subfolder: {full_path} due to exclude_folders setting.", xbmc.LOGDEBUG)
            except Exception as e:
                utils.log(f"Error listing subfolders in {current_dir}: {str(e)}", xbmc.LOGERROR)
        utils.log(f"Finished recursive scan. Total folders identified: {len(folders_to_scan)}", xbmc.LOGINFO)
        return folders_to_scan

    def _is_video_file(self, filename: str) -> bool:
        extensions_str = self._get_setting('file_extensions')
        allowed_extensions = [ext.strip().lower() for ext in extensions_str.split(',') if ext.strip()]
        file_ext = os.path.splitext(filename)[1].lower()
        return file_ext in allowed_extensions

    def _is_excluded(self, filename: str, exclude_pattern: List[str]) -> bool:
        for pattern in exclude_pattern:
            if pattern and pattern in filename.lower():
                return True
        return False

    def _sort_files(self, files: List[Dict[str, Any]]) -> None:
        sort_mode = self._get_setting_int('sort_mode')
        if sort_mode == 0:  # Newest First
            files.sort(key=lambda x: x['mtime'], reverse=True)
        elif sort_mode == 1:  # A-Z
            files.sort(key=lambda x: x['name'].lower())
        elif sort_mode == 2:  # Z-A
            files.sort(key=lambda x: x['name'].lower(), reverse=True)
        elif sort_mode == 3:  # Random
            random.shuffle(files)
        elif sort_mode == 4:  # Smallest First
            files.sort(key=lambda x: x['size'])
        elif sort_mode == 5:  # Largest First
            files.sort(key=lambda x: x['size'], reverse=True)
        elif sort_mode == 6:  # Shortest First (by duration - requires parsing, not implemented)
            pass
        elif sort_mode == 7:  # Longest First (by duration - requires parsing, not implemented)
            pass

    def _get_cleaned_playlist_display_name(self, original_name: str) -> str:
        """Applies general filename cleanup settings to a string for playlist display.
           Crucially, it first unquotes the name to ensure human-readable text.
        """
        # First, unquote the name to remove URL encoding for display purposes
        unquoted_name = urllib.parse.unquote(original_name)
        cleaned_name = unquoted_name

        # Only apply cleaning if the filename cleanup setting is enabled
        if self._get_setting_bool('filename_cleanup_enable'):
            delete_words_general = [w.strip() for w in self._get_setting('delete_words').split(',') if w.strip()]
            switch_words_general_str = self._get_setting('switch_words')
            cleanup_regex_general = self._get_setting('cleanup_filename_regex')
            cleanup_replace_general = self._get_setting('cleanup_filename_replace_with')
            
            cleaned_name = downloader.clean_download_filename(
                cleaned_name, 
                delete_words_general, 
                switch_words_general_str, 
                cleanup_regex_general, 
                cleanup_replace_general
            )
        return cleaned_name

    def _generate_m3u_playlist(self, playlist_name: str, files: List[Dict[str, Any]]) -> None:
        playlist_path = os.path.join(utils.PLAYLIST_DIR, f"{playlist_name}.m3u")
        playlist_content = "#EXTM3U\n"

        show_folder_names = self._get_setting_bool('show_folder_names')
        show_metadata = self._get_setting_bool('show_metadata')
        show_duration = self._get_setting_bool('show_duration')
        
        # New settings for coloring folder names
        color_folder_name = self._get_setting_bool('color_folder_name') 
        folder_name_color = self._get_setting('folder_name_color') 

        for f in files:
            # The actual path to be written to the M3U file.
            # This should remain as Kodi expects it for playback (e.g., davs://...)
            file_path_for_m3u = f['path']
            
            # For display purposes (EXTINF line), we want a clean, unquoted name.
            base_filename_for_display = os.path.basename(f['path']) # Get basename from the *original* path
            display_name = self._get_cleaned_playlist_display_name(base_filename_for_display)

            if show_folder_names:
                parent_folder_for_display = os.path.basename(os.path.dirname(f['path'])) # Get parent folder from *original* path
                cleaned_parent_folder = self._get_cleaned_playlist_display_name(parent_folder_for_display) # Clean folder name too
                
                if color_folder_name and folder_name_color:
                    display_name = f"[COLOR {folder_name_color}][{cleaned_parent_folder}][/COLOR] {display_name}"
                else:
                    display_name = f"[{cleaned_parent_folder}] {display_name}"
            
            extinf_data = []
            if show_metadata:
                extinf_data.append(f"size={f['size']}")
                extinf_data.append(f"mtime={f['mtime'].strftime('%Y-%m-%d')}")
            
            if show_duration:
                extinf_data.append("0") # Placeholder for duration. Real implementation would parse video duration.
            
            # Construct the EXTM3U line with the *display* name
            extinf_line = f"#EXTINF:{','.join(extinf_data) if extinf_data else '-1'},{display_name}"
            
            # Write the EXTM3U line and then the actual file path
            playlist_content += f"{extinf_line}\n{file_path_for_m3u}\n"

        try:
            with xbmcvfs.File(playlist_path, 'w') as f_write:
                f_write.write(playlist_content)
            self.playlists_generated += 1
            utils.log(f"Successfully created playlist: {playlist_path}", xbmc.LOGINFO)
        except Exception as e:
            utils.show_ok_dialog(utils.ADDON_NAME, f"Failed to create playlist: {e}")
            utils.log(f"Failed to create playlist {playlist_path}: {str(e)}", xbmc.LOGERROR)

    def create_playlist(self) -> None:
        folder_paths: List[str] = []
        while True:
            selected_folder = utils.select_folder(f"Select folder {len(folder_paths) + 1}", '')
            if selected_folder:
                folder_paths.append(selected_folder)
                # Prompt after first folder added to allow adding more
                if not utils.show_yesno_dialog(utils.ADDON_NAME, "Add another folder?"):
                    break
            else:
                if not folder_paths: 
                    utils.show_ok_dialog(utils.ADDON_NAME, "No folder selected. Playlist creation cancelled.")
                break

        if not folder_paths:
            return

        playlist_name = utils.get_keyboard_input(heading="Enter playlist name")
        if not playlist_name:
            return

        # Reset counts for the entire create playlist operation
        self.files_processed_count = 0
        self.folders_processed_count = 0
        
        all_files_combined: List[Dict[str, Any]] = []
        for folder_path in folder_paths:
            # Collect files from each selected folder
            collected_from_current_folder = self._collect_files_for_playlist(folder_path)
            all_files_combined.extend(collected_from_current_folder)
            
        # Apply global limits and rotation to the COMBINED list
        total_file_limit_enabled = self._get_setting('limit_mode') == '1'
        total_file_count_limit = self._get_setting_int('total_file_count')

        utils.log(f"Total files collected from all selected folders before final global limit: {len(all_files_combined)}", xbmc.LOGINFO)
        if total_file_limit_enabled:
            if total_file_count_limit > 0 and len(all_files_combined) > total_file_count_limit:
                all_files_combined = all_files_combined[:total_file_count_limit]
                utils.log(f"Limited to {len(all_files_combined)} total files.", xbmc.LOGINFO)

        enable_rotation = self._get_setting_bool('enable_rotation')
        if enable_rotation:
            offset = self._get_setting_int('rotation_offset')
            if offset > 0 and len(all_files_combined) > 0:
                offset %= len(all_files_combined)
                all_files_combined = all_files_combined[offset:] + all_files_combined[:offset]
                utils.log(f"Applied rotation with offset {offset} to combined list.", xbmc.LOGINFO)

        # Generate the M3U playlist ONLY ONCE with all combined files
        utils.log(f"Final combined number of files for playlist '{playlist_name}': {len(all_files_combined)}", xbmc.LOGINFO)
        self._generate_m3u_playlist(playlist_name, all_files_combined)
        utils.show_ok_dialog(utils.ADDON_NAME, f"Playlist '{playlist_name}.m3u' created successfully from {len(folder_paths)} folder(s).")

    def quick_scan(self) -> None:
        # Loop to allow scanning multiple folders
        folder_paths: List[str] = []
        while True:
            selected_folder = utils.select_folder(f"Select folder to scan {len(folder_paths) + 1}", '')
            if selected_folder:
                folder_paths.append(selected_folder)
                if not utils.show_yesno_dialog(utils.ADDON_NAME, "Scan another folder?"):
                    break
            else:
                if not folder_paths: # No folder selected at all initially
                    utils.show_ok_dialog(utils.ADDON_NAME, "No folder selected. Scan cancelled.")
                break # Break out of the loop if user cancelled folder selection

        if not folder_paths:
            return
        
        # Reset counts for this quick scan operation
        self.files_processed_count = 0
        self.folders_processed_count = 0

        # Quick scan collects files and creates a temporary playlist for each selected folder and then deletes it
        # This is for scanning purposes, not for persistent playlists.
        for folder_path in folder_paths:
            # Collect files for the current folder based on addon settings
            collected_files_for_scan = self._collect_files_for_playlist(folder_path)
            
            # Apply global limits and rotation to the collected files for THIS scan's temp playlist
            total_file_limit_enabled = self._get_setting('limit_mode') == '1'
            total_file_count_limit = self._get_setting_int('total_file_count')

            if total_file_limit_enabled:
                if total_file_count_limit > 0 and len(collected_files_for_scan) > total_file_count_limit:
                    collected_files_for_scan = collected_files_for_scan[:total_file_count_limit]

            enable_rotation = self._get_setting_bool('enable_rotation')
            if enable_rotation:
                offset = self._get_setting_int('rotation_offset')
                if offset > 0 and len(collected_files_for_scan) > 0:
                    offset %= len(collected_files_for_scan)
                    collected_files_for_scan = collected_files_for_scan[offset:] + collected_files_for_scan[:offset]

            self._generate_m3u_playlist("temp_scan", collected_files_for_scan) 
            # Ensure the temp playlist is deleted after scan information is gathered
            xbmcvfs.delete(os.path.join(utils.PLAYLIST_DIR, "temp_scan.m3u")) 

        utils.show_ok_dialog(utils.ADDON_NAME, 
                             f"Scan complete!\nFolders processed: {self.folders_processed_count}\nFiles processed: {self.files_processed_count}")

    def manage_sets(self) -> None:
        while True:
            set_names = list(self.sets.keys())
            menu_items = ["Create New Set"] + set_names

            selected_index = utils.select_from_list(utils.ADDON_NAME, menu_items)

            if selected_index is None or selected_index == -1: # Handles back button
                break

            if selected_index == 0:
                self._create_new_set()
            else:
                selected_set_name = set_names[selected_index - 1]
                self._edit_existing_set(selected_set_name)

    def _create_new_set(self) -> None:
        set_name = utils.get_keyboard_input(heading="Enter new set name")
        if not set_name:
            return
        if set_name in self.sets:
            utils.show_ok_dialog(utils.ADDON_NAME, "Set with this name already exists.")
            return

        initial_folder_path = utils.select_folder(heading=f"Select initial folder for '{set_name}' (optional)")
        
        folders_for_set = []
        if initial_folder_path:
            folders_for_set.append(initial_folder_path)
            utils.log(f"Initial folder selected for new set '{set_name}': {initial_folder_path}", xbmc.LOGINFO)
            # Add prompt to add another folder after the first one is selected
            while utils.show_yesno_dialog(utils.ADDON_NAME, "Add another folder to this set?"):
                next_folder = utils.select_folder(heading=f"Select another folder for '{set_name}'")
                if next_folder and next_folder not in folders_for_set:
                    folders_for_set.append(next_folder)
                    utils.log(f"Added additional folder to new set '{set_name}': {next_folder}", xbmc.LOGINFO)
                elif next_folder:
                    utils.show_ok_dialog(utils.ADDON_NAME, "Folder already added or invalid path.")
                else: # User cancelled folder selection
                    break
        else:
            utils.log(f"No initial folder selected for new set '{set_name}'.", xbmc.LOGINFO)
            # If no initial folder selected, ask if they still want to create an empty set
            if not utils.show_yesno_dialog(utils.ADDON_NAME, 
                                           f"No initial folder selected for '{set_name}'.\nDo you want to create an empty set and add folders later?"):
                utils.show_ok_dialog(utils.ADDON_NAME, "Set creation cancelled.")
                return # User cancelled creating even an empty set

        self.sets[set_name] = {
            'folders': folders_for_set, # Will be empty if user chose to create an empty set
            'last_updated': datetime.now().isoformat(),
            'settings': utils.get_all_addon_settings()
        }
        utils.save_json(self.sets, utils.CONFIG_FILE)
        utils.show_ok_dialog(utils.ADDON_NAME, f"Set '{set_name}' created successfully.")

    def _edit_existing_set(self, set_name: str) -> None:
        action_options = [
            "Add Folder",
            "Remove Folder",
            "Edit Set Settings",
            "Generate Playlist for this Set", 
            "Delete Set"
        ]
        
        while True:
            selected_action_index = utils.select_from_list(f"Actions for '{set_name}'", action_options)
            if selected_action_index is None or selected_action_index == -1: # Handles back button
                break

            if selected_action_index == 0:  # Add Folder
                while True: # Loop to allow adding multiple folders
                    new_folder = utils.select_folder(heading=f"Add folder to '{set_name}'")
                    if new_folder:
                        if new_folder not in self.sets[set_name]['folders']:
                            self.sets[set_name]['folders'].append(new_folder)
                            utils.save_json(self.sets, utils.CONFIG_FILE)
                            utils.show_ok_dialog(utils.ADDON_NAME, f"Folder added to '{set_name}'.")
                            if not utils.show_yesno_dialog(utils.ADDON_NAME, "Add another folder?"):
                                break # User chose not to add more
                        else:
                            utils.show_ok_dialog(utils.ADDON_NAME, "Folder already in set or invalid path.")
                            if not utils.show_yesno_dialog(utils.ADDON_NAME, "Try adding another folder?"):
                                break # User chose not to try again
                    else: # User cancelled folder selection
                        utils.show_ok_dialog(utils.ADDON_NAME, "No folder selected.")
                        break # Exit add folder loop
            elif selected_action_index == 1:  # Remove Folder
                folders = self.sets[set_name]['folders']
                if not folders:
                    utils.show_ok_dialog(utils.ADDON_NAME, "No folders to remove.")
                    continue
                folder_to_remove_index = utils.select_from_list(f"Remove from '{set_name}'", folders)
                if folder_to_remove_index is not None and folder_to_remove_index != -1:
                    removed_folder = folders.pop(folder_to_remove_index)
                    utils.save_json(self.sets, utils.CONFIG_FILE)
                    utils.show_ok_dialog(utils.ADDON_NAME, f"Folder '{removed_folder}' removed.")
            elif selected_action_index == 2:  # Edit Set Settings
                original_addon_settings = self._get_current_addon_settings()
                self._load_set_settings(set_name)
                utils.ADDON.openSettings()
                if utils.show_yesno_dialog(utils.ADDON_NAME, f"Save current settings as '{set_name}'s settings?"):
                    self._save_set_settings(set_name, self._get_current_addon_settings())
                self._apply_set_settings_to_addon(original_addon_settings)
            elif selected_action_index == 3: # Generate Playlist for this Set 
                if not self.sets[set_name]['folders']:
                    utils.show_ok_dialog(utils.ADDON_NAME, "No folders configured for this set to generate a playlist.")
                    continue
                original_addon_settings = self._get_current_addon_settings()
                self._load_set_settings(set_name) # Apply set specific settings
                
                # Reset counts for this single set generation
                self.files_processed_count = 0
                self.folders_processed_count = 0

                all_files_combined: List[Dict[str, Any]] = []
                for folder_path in self.sets[set_name]['folders']:
                    collected_from_current_folder = self._collect_files_for_playlist(folder_path)
                    all_files_combined.extend(collected_from_current_folder)
                
                # Apply global limits and rotation to the COMBINED list for this set
                total_file_limit_enabled = self._get_setting('limit_mode') == '1'
                total_file_count_limit = self._get_setting_int('total_file_count')

                if total_file_limit_enabled:
                    if total_file_count_limit > 0 and len(all_files_combined) > total_file_count_limit:
                        all_files_combined = all_files_combined[:total_file_count_limit]

                enable_rotation = self._get_setting_bool('enable_rotation')
                if enable_rotation:
                    offset = self._get_setting_int('rotation_offset')
                    if offset > 0 and len(all_files_combined) > 0:
                        offset %= len(all_files_combined)
                        all_files_combined = all_files_combined[offset:] + all_files_combined[:offset]

                self._generate_m3u_playlist(set_name, all_files_combined)
                self._apply_set_settings_to_addon(original_addon_settings) # Restore original settings
                utils.show_ok_dialog(utils.ADDON_NAME, f"Playlist for '{set_name}' generated from {len(self.sets[set_name]['folders'])} folder(s).")
            elif selected_action_index == 4:  # Delete Set
                if utils.show_yesno_dialog("Confirm", f"Delete '{set_name}'?"):
                    del self.sets[set_name]
                    utils.save_json(self.sets, utils.CONFIG_FILE)
                    utils.show_ok_dialog(utils.ADDON_NAME, f"Set '{set_name}' deleted.")
                    break # Exit edit set menu after deletion

    def update_all_sets(self) -> None:
        if not self.sets:
            utils.show_ok_dialog(utils.ADDON_NAME, "No sets to update.")
            return

        original_addon_settings = self._get_current_addon_settings()
        self.playlists_generated = 0
        
        for set_name, set_data in self.sets.items():
            utils.log(f"Updating set: {set_name}", xbmc.LOGINFO)
            self._apply_set_settings_to_addon(set_data['settings'])
            
            # Reset counts for EACH set's generation
            self.files_processed_count = 0
            self.folders_processed_count = 0

            if 'folders' in set_data and set_data['folders']:
                all_files_combined_for_set: List[Dict[str, Any]] = []
                for folder_path in set_data['folders']:
                    collected_from_current_folder = self._collect_files_for_playlist(folder_path)
                    all_files_combined_for_set.extend(collected_from_current_folder)
                
                # Apply global limits and rotation to the COMBINED list for this set
                total_file_limit_enabled = self._get_setting('limit_mode') == '1'
                total_file_count_limit = self._get_setting_int('total_file_count')

                if total_file_limit_enabled:
                    if total_file_count_limit > 0 and len(all_files_combined_for_set) > total_file_count_limit:
                        all_files_combined_for_set = all_files_combined_for_set[:total_file_count_limit]

                enable_rotation = self._get_setting_bool('enable_rotation')
                if enable_rotation:
                    offset = self._get_setting_int('rotation_offset')
                    if offset > 0 and len(all_files_combined_for_set) > 0:
                        offset %= len(all_files_combined_for_set)
                        all_files_combined_for_set = all_files_combined_for_set[offset:] + all_files_combined_for_set[:offset]

                self._generate_m3u_playlist(set_name, all_files_combined_for_set)
                self.sets[set_name]['last_updated'] = datetime.now().isoformat()
            else:
                utils.log(f"Set '{set_name}' has no folders defined. Skipping.", xbmc.LOGWARNING)
        
        utils.save_json(self.sets, utils.CONFIG_FILE)
        self._apply_set_settings_to_addon(original_addon_settings)
        utils.show_ok_dialog(utils.ADDON_NAME, f"All sets updated. Generated {self.playlists_generated} playlists.")

    def run_download_action(self, url: str) -> None:
        if not self._get_setting_bool('enable_download'):
            utils.show_ok_dialog(utils.ADDON_NAME, "Download feature is disabled in settings.")
            return

        download_location_mode = self._get_setting_int('download_location_mode')
        download_folder = ""
        if download_location_mode == 0:  # Default
            download_folder = self._get_setting('default_download_folder')
        elif download_location_mode == 1:  # Clips
            download_folder = self._get_setting('clips_download_folder')
        elif download_location_mode == 2:  # Adult
            download_folder = self._get_setting('adult_download_folder')
        
        if not download_folder:
            utils.show_ok_dialog(utils.ADDON_NAME, "Download folder not configured for selected download type.")
            return
        
        # Clean the filename for download, but keep it URL-encoded if it's coming from an URL
        # The downloader.clean_download_filename function should handle unquoting internally if needed for cleaning,
        # but the final filename for the filesystem typically should be unquoted.
        # Let's ensure filename is unquoted before passing to clean_download_filename
        unquoted_filename_from_url = urllib.parse.unquote(os.path.basename(urllib.parse.urlparse(url).path))
        
        cleaned_filename = self._get_cleaned_download_filename(unquoted_filename_from_url)
        
        destination_path = os.path.join(download_folder, cleaned_filename)

        if utils.show_yesno_dialog(utils.ADDON_NAME, f"Download to:\n{destination_path}?"):
            # downloader.download_file needs the original URL for download
            downloader.download_file(url, destination_path)

    def _get_cleaned_download_filename(self, filename_from_url_unquoted: str) -> str:
        """
        Cleans the filename for download. Assumes filename_from_url_unquoted is already unquoted.
        """
        cleaned_filename = filename_from_url_unquoted
        
        if self._get_setting_bool('filename_cleanup_enable'):
            delete_words_general = [w.strip() for w in self._get_setting('delete_words').split(',') if w.strip()]
            switch_words_general_str = self._get_setting('switch_words')
            cleanup_regex_general = self._get_setting('cleanup_filename_regex')
            cleanup_replace_general = self._get_setting('cleanup_filename_replace_with')
            
            cleaned_filename = downloader.clean_download_filename(
                cleaned_filename, # This is already unquoted
                delete_words_general, 
                switch_words_general_str, 
                cleanup_regex_general, 
                cleanup_replace_general
            )

        # Apply adult cleanup specifically for adult download mode if enabled
        if self._get_setting_bool('enable_adult_cleanup') and self._get_setting_int('download_location_mode') == 2:
            adult_delete_words = [w.strip() for w in self._get_setting('adult_delete_words').split(',') if w.strip()]
            adult_switch_words_str = self._get_setting('adult_switch_words')
            
            cleaned_filename = downloader.clean_download_filename(
                cleaned_filename, # This is the already cleaned filename
                adult_delete_words, 
                adult_switch_words_str, 
                '', # Adult cleanup uses its own delete/switch, no regex/replace from general here
                ''  
            )
        
        return cleaned_filename