import xbmc
import xbmcvfs
import urllib.request
import re
from typing import List

import resources.lib.utils as utils

def download_file(url: str, destination_path: str) -> None:
    try:
        # Placeholder for directory creation
        dest_dir = xbmcvfs.SplitPath(destination_path)[0]
        if not xbmcvfs.exists(dest_dir):
            xbmcvfs.mkdirs(dest_dir)

        # Placeholder for download
        urllib.request.urlretrieve(url, destination_path)
        utils.show_ok_dialog(utils.ADDON_NAME, f"Download Complete:\n{destination_path}")
        utils.log(f"Downloaded {url} to {destination_path}")
    except Exception as e:
        utils.show_ok_dialog(utils.ADDON_NAME, f"Download Failed:\n{str(e)}")
        utils.log(f"Download failed for {url} to {destination_path}: {str(e)}", xbmc.LOGERROR)

def clean_download_filename(
    filename: str, 
    words_to_delete: List[str], 
    words_to_switch: str, 
    regex_pattern: str, 
    regex_replace_with: str
) -> str:
    cleaned_filename = filename

    for word in words_to_delete:
        cleaned_filename = re.sub(r'\b' + re.escape(word) + r'\b', '', cleaned_filename, flags=re.IGNORECASE).strip()

    if words_to_switch:
        switch_pairs = [pair.strip().split(':') for pair in words_to_switch.split(',') if pair.strip()]
        for pair in switch_pairs:
            if len(pair) == 2:
                cleaned_filename = cleaned_filename.replace(pair[0], pair[1])
            elif len(pair) == 1:
                cleaned_filename = cleaned_filename.replace(pair[0], '')

    if regex_pattern:
        try:
            cleaned_filename = re.sub(regex_pattern, regex_replace_with, cleaned_filename)
        except re.error as e:
            utils.log(f"Regex error in cleanup: {e}", xbmc.LOGERROR)

    cleaned_filename = re.sub(r'\s+', ' ', cleaned_filename).strip()
    return cleaned_filename