import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import json
import xbmc
from typing import Any, Dict, List, Optional

ADDON: xbmcaddon.Addon
ADDON_ID: str
ADDON_NAME: str
ADDON_PROFILE: str
CONFIG_FILE: str
PLAYLIST_DIR: str
DIALOG: xbmcgui.Dialog

def init_addon_globals() -> None:
    global ADDON, ADDON_ID, ADDON_NAME, ADDON_PROFILE, CONFIG_FILE, PLAYLIST_DIR, DIALOG
    ADDON = xbmcaddon.Addon()
    ADDON_ID = ADDON.getAddonInfo('id')
    ADDON_NAME = ADDON.getAddonInfo('name')
    ADDON_PROFILE = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
    CONFIG_FILE = os.path.join(ADDON_PROFILE, 'playlist_sets.json')
    PLAYLIST_DIR = xbmcvfs.translatePath('special://profile/playlists/video/')
    DIALOG = xbmcgui.Dialog()

def log(msg: str, level: int = xbmc.LOGINFO) -> None:
    xbmc.log(f"[{ADDON_ID}] {msg}", level)

def get_setting(setting_id: str, default: str = '') -> str:
    return ADDON.getSetting(setting_id) or default

def set_setting(setting_id: str, value: Any) -> None:
    ADDON.setSetting(setting_id, str(value))

def load_json(file_path: str) -> Dict[str, Any]:
    try:
        if xbmcvfs.exists(file_path):
            with xbmcvfs.File(file_path, 'r') as f:
                return json.loads(f.read())
    except Exception as e:
        log(f"Load failed: {str(e)}", xbmc.LOGERROR)
    return {}

def save_json(data: Dict[str, Any], file_path: str) -> None:
    try:
        with xbmcvfs.File(file_path, 'w') as f:
            f.write(json.dumps(data, indent=4))
    except Exception as e:
        log(f"Save failed: {str(e)}", xbmc.LOGERROR)

def show_ok_dialog(heading: str, message: str) -> None:
    DIALOG.ok(heading, message)

def show_yesno_dialog(heading: str, message: str) -> bool:
    return DIALOG.yesno(heading, message)

def get_keyboard_input(default_text: str = '', heading: str = '') -> str:
    keyboard = xbmc.Keyboard(default_text, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    return ''

# --- MODIFIED FUNCTION ---
def select_folder(heading: str, default_path: str = '') -> str:
    # Mode 3 means 'folders' only.
    # The 'path' argument is the starting path for the browser.
    path = DIALOG.browse(3, heading, 'files', '', False, False, default_path)
    return path

def select_from_list(heading: str, _list: List[str]) -> Optional[int]:
    return DIALOG.select(heading, _list)

def get_all_addon_settings() -> Dict[str, str]:
    all_settings: Dict[str, str] = {}
    setting_ids = [
        'file_extensions', 'exclude_pattern', 'exclude_folders', 'min_file_size',
        'enable_max_size', 'max_file_size', 'recursive_scan', 'enable_date_filter',
        'min_file_date', 'sort_mode', 'folder_sort_mode', 'custom_folder_order',
        'newest_files', 'limit_mode', 'file_count', 'total_file_count',
        'enable_rotation', 'rotation_offset', 'show_folder_names', 'show_metadata',
        'show_duration', 'enable_download', 'show_download_menu', 'download_location_mode',
        'default_download_folder', 'clips_download_folder', 'adult_download_folder',
        'enable_adult_cleanup', 'adult_delete_words', 'adult_switch_words',
        'filename_cleanup_enable', 'delete_words', 'switch_words', 'cleanup_filename_regex',
        'cleanup_filename_replace_with', 'enable_backups', 'max_backups'
    ]
    for setting_id in setting_ids:
        all_settings[setting_id] = ADDON.getSetting(setting_id)
    return all_settings

def set_all_addon_settings(settings: Dict[str, str]) -> None:
    for setting_id, value in settings.items():
        ADDON.setSetting(setting_id, str(value))