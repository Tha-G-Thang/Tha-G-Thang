import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os
import urllib.parse

import resources.lib.utils as utils
from resources.lib.playlist_manager import PlaylistManager

if __name__ == '__main__':
    utils.init_addon_globals()

    if not xbmcvfs.exists(utils.ADDON_PROFILE):
        xbmcvfs.mkdirs(utils.ADDON_PROFILE)
    if not xbmcvfs.exists(utils.PLAYLIST_DIR):
        xbmcvfs.mkdirs(utils.PLAYLIST_DIR)

    manager = PlaylistManager()
    
    # This block replaces the problematic line that caused the IndexError.
    # It safely checks if sys.argv[2] exists before trying to parse it.
    if len(sys.argv) > 2:
        args = urllib.parse.parse_qs(sys.argv[2][1:])
    else:
        args = {} # No arguments, so initialize args as an empty dictionary

    action = args.get('action', [None])[0]
    url = args.get('url', [None])[0]

    if action == 'download' and url:
        manager.run_download_action(url)
    else:
        dialog = xbmcgui.Dialog()
        while True:
            choice = dialog.select(utils.ADDON_NAME, [
                "Create Playlist",
                "Quick Scan (No Playlist)",
                "Manage Folder Sets",
                "Update All Sets",
                "Settings",
                "Exit"
            ])
            
            if choice == 0:
                manager.create_playlist()
            elif choice == 1:
                manager.quick_scan()
            elif choice == 2:
                manager.manage_sets()
            elif choice == 3:
                manager.update_all_sets()
            elif choice == 4:
                utils.ADDON.openSettings()
            elif choice in (5, -1):
                break